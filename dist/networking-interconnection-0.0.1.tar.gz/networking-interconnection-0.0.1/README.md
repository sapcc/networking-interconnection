# networking-interconnection
Networking interconnection Neutron service driver.

The repository hosts an implementation of Openstack drivers to support BGPVPN interconnection to provide the following Openstack extensions:

* BGPVPN cross-region inteconnections

The scheme how it works:

![alt text](https://github.com/sapcc/networking-interconnection/blob/stable/ussuri-m3/interconnection-scheme.png?raw=true)

**The current state in beta, there are currently issues with performance degradation over time being investigated**
